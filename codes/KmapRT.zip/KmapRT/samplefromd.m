function id=samplefromd(d);
%samples from density d
u=cumsum(d);
tu=u-rand;
tu(tu<0)=inf;
[junk id]=min(tu); 