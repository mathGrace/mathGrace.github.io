function [centers mincent]=kqf(X,nc,cc,maxiter,affine,quiet);
%function [centers mincent]=kqf(X,nc,cc,maxiter,affine,quiet);
%Lloyd iteration for k-subspaces/ k q-flats 
%nc is number of planes
%cc is dimension of planes
%maxiter is maximum number of Lloyd iterations
%affine=0 makes all planes pass through the origin
%quiet=1 supresses some diagnostic/runtime info
%



if ~exist('quiet','var')
    quiet=1;
end


if ~exist('affine','var')
    affine=0;
end


[d N]=size(X);
sx=sum(X.^2);
if numel(nc)>1
    centers=nc;
    nc=length(centers);
else
   centers=initialize_kqf_pfi(X,nc,cc,affine,sx);
end



for k=1:maxiter
    for s=1:nc
        ds(s,:)=distance_to_subspace(X,centers{s},affine,sx);
    end
    [ju mincent]=min(ds);
    [b plid]=mvi(mincent);%todo fix empty centers
    for s=1:min(nc,length(plid))
        if affine
            tx=X(:,plid{s});
            centers{s}(:,1)=mean(tx,2);
            tx=bsxfun(@minus,tx,centers{s}(:,1));
%             Q=tx*tx';
            %             [uu ss vv]=svd(Q);
            opts.tol=16*eps;
            [uu ss vv] = lansvd(tx,cc,'L',opts);
            % %            [uu ss vv]=svd(tx,'econ');
            centers{s}(:,2:cc+1)=uu(:,1:cc);
%             [uu ss]=eig(Q);
%             centers{s}(:,2:cc+1)=uu(:,end-cc+1:end);
        else
            tx=X(:,plid{s});
            opts.tol=16*eps;
            [uu ss vv] = lansvd(tx,cc,'L',opts);
            %             Q=tx*tx';
            %             [uu ss vv]=svd(Q);
            % %            [uu ss vv]=svd(tx,'econ');
            centers{s}=uu(:,1:cc);
            %             [uu ss]=eig(Q);
            %             centers{s}=uu(:,end-cc+1:end);
        end
        
    end
    if ~quiet
        sum(ju)
    end
end





function centers=initialize_kqf_pfi(X,nc,cc,affine,sx);

[d N]=size(X);
dd=inf(1,N);
a=ones(1,N);  %probabalistic farthest insertion+nn:
%    sx=sum(X.^2);
for k=1:nc 
    a=a/sum(a);
    id=samplefromd(a);
    x=X(:,id);
    ds=sum(x.^2)+sx-2*x'*X;
    [ju juu]=sort(ds);
    rk=0;
    count=0;
    while rk<cc
        count=count+1;
        tx=X(:,juu(1:count*cc+11));
        if affine
            mm=mean(tx,2);
            tx=bsxfun(@minus,tx,mm);
            rk=rank(tx);
        else
            rk=rank(tx);
        end
        if count>10
            error('data locally too low rank, cannot find cc independent points in a neighborhood\n');
        end
    end
    
    if affine
        opts.tol=16*eps;
        [uu ss vv] = lansvd(tx,cc,'L',opts);
        %             Q=tx*tx';
        %             [uu ss vv]=svd(Q);
        centers{k}(:,1)=mm;
        centers{k}(:,2:cc+1)=uu(:,1:cc);
        %             [uu ss]=eig(Q);
        %             centers{k}(:,1)=mm;
        %             centers{k}(:,2:cc+1)=uu(:,end-cc+1:end);
    else
        opts.tol=16*eps;
        [uu ss vv] = lansvd(tx,cc,'L',opts);
        %             Q=tx*tx';
        %             [uu ss vv]=svd(Q);
        % %            [uu ss vv]=svd(tx,'econ');
        centers{k}=uu(:,1:cc);
        %             [uu ss]=eig(Q);
        %             centers{k}=uu(:,end-cc+1:end);
    end
    
    dd=min(dd,distance_to_subspace(X,centers{k},affine,sx));
    a=dd;
end






function ds=distance_to_subspace(X,P,affine,ds)
if nargin<4
    ds=sum(X.^2);
end

if affine
    p=P(:,1);
    U=P(:,2:end);
    np=sum(p.^2);
    Up=U'*p;
    ds=ds-2*p'*X+np;
    uxmup=bsxfun(@minus,U'*X,Up);
    ds=ds-sum(uxmup.^2);
else
    ds=ds-sum((P'*X).^2);
end





function id=samplefromd(d);
%samples from density d
u=cumsum(d);
tu=u-rand;
tu(tu<0)=inf;
[junk id]=min(tu);

