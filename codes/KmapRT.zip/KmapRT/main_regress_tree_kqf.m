function [U D mX mY V ploc b mp]=main_regress_tree_kqf(X,Y,nc,q,depth,maxiter,tol,lambda,subtype)
% function [U D mX mY V ploc b mp]=main_regress_tree_kqf(X,Y,nc,q,depth,maxiter,tol,lambda,subtype)
% This is the main function for the regression via tree structure + k
% q-flats
%
% Input:
%     X        -    data points as in columns, dxn
%     Y        -    data responses as in columns, pxn
%     nc       -    the number of linear mappings
%     q        -    the rank of the mappings
%     depth    -    the depth of the tree structure (not including the root)
%     maxiter  -    the maximal number of iterations for the alternation
%              between updating the mappings and the tree leaf assignments.
% Optional Input:
%     tol      -    default is 0.0001 (can be adapted to the data's scale)
%     lambda   -    a regularization parameter, default is 0.001 (can be adapted to the data's scale)
%     subtype  -    binary, 1 (default) creates randomized tree; 0 creates
%              deterministic tree.
%
%
% Output:
%     U        -    a 1x(nc) cell array, each entry is a rxd matrix
%     D        -    a 1x(nc) cell array, each entry is a pxr matrix; (U and D together define the low rank linear mapping; each is D{i}*U{i})
%     mX       -    a rx(nc) matrix, each column is a center of X in the projection space
%              for a linear mapping
%     mY       -    a rx(nc) matrix, each column is a center of Y for a
%              linear mapping
%     V        -    a dx( 2^(depth)-1 ) matrix; the directions (as in columns) of hyperplanes for the subdivision
%     b        -    a 1x( 2^(depth)-1 ) vector; the offset values of hyperplanes for the subdivision
%                   (the hyperplane is v^T * x - b = 0)
%     ploc     -    a matrix of 3 rows that stores the tree structure; the
%              number of clumns depends on the structure
%     mp       -    assignments of leaf nodes to mappings.


if ~exist('subtype','var')
    subtype=1;
end

if ~exist('tol','var')
    tol = 0.0001;
end

if ~exist('lambda','var')
    lambda = 0.001;
end
   


% [d N]=size(X);

% Create the binary tree stucture by subdividing X w.r.t. Y
[V ploc b]=binary_subdivide(X,Y,depth,tol,subtype);


% Initialize K mappings by clustering in Y
[~, mincent]=kqf(Y,nc,q,10,1,1);    % cluster Y in to nc q-dimensional subspaces; mincent is the labels
[~, ulist]=mvi(mincent); % find the incides for each label and store them in a cell



% Update the mappings
snum = min(nc,length(ulist));
D = cell(1,snum);
U = cell(1,snum);
mX = zeros(q,snum);
mY = zeros(size(Y,1),snum);
for s=1:snum
    [D{s} U{s} mX(:,s) mY(:,s)]=update_mapping(X(:,ulist{s}),Y(:,ulist{s}),q,lambda); 
end


% assign each of the data point in X to a leaf node of the tree defined by
% V,b,ploc
p=binary_fprop_dumb(X,V,b,ploc);
[pb plid]=mvi(p);
sd=zeros(length(plid),1);
sys=sum(Y.^2);


for k=1:maxiter

    %compute the errors for each mapping at each point:
    for s=1:min(nc,length(U))
        P=bsxfun(@minus,U{s}*X,mX(:,s));
        R=bsxfun(@plus,D{s}*P,mY(:,s));
        dists(s,:)=sum((Y-R).^2);
    end
   
    %each leaf votes for a mapping
    ulist=cell(nc,1);
    for t=1:length(plid)     
        u=sum(dists(:,plid{t}),2);
        [ju juu]=min(u);
        sd(t)=ju;
        mp(pb(t))=juu;
        ulist{juu}=[ulist{juu} ;plid{t}];
    end
    
    %if a mapping is not used by any leaf, find some leave(s) to use it:
    nused=zeros(nc,1);
    for s=1:nc
        if length(ulist{s})<2*q
            nused(s)=1;            
        end
    end
    while max(nused)
           
        for s=1:nc
            if nused(s)
                id=samplefromd(sd/sum(sd));
                sd(id)=0;
                uid=plid{id};                
                while length(uid)<2*q
                    rid=ceil(rand*length(uid));
                    ty=Y(:,uid(rid));
                    td=sum(ty.^2)+sys-2*ty'*Y;
                    [junk nnid]=sort(td);
                    nnid=nnid(1:q);
                    nnid=nnid(randperm(q));
                    near_leaf=p(nnid(1));
                    uid=union(uid, find(p==near_leaf));
                    sd(near_leaf)=0;
                end
                ulist{s}=uid;
                nused(s)=0;
            end
            
        end
        for s=1:nc
            if length(ulist{s})<2*q
                nused(s)=1;            
            end
        end     
    end
    
    
    %update each mapping.
    for s=1:nc
        [D{s} U{s} mX(:,s) mY(:,s)]=update_mapping(X(:,ulist{s}),Y(:,ulist{s}),q,lambda); 
    end

    
    
end




function [D U mX mY]=update_mapping(X,Y,q,lambda)


d = size(X,1);
X = [X;ones(1,size(X,2))];
I = diag([ones(d,1);0]);
XXt=X*X';
mY=mean(Y,2);
Y=bsxfun(@minus,Y,mY);
n_min = min(size(Y));
if n_min > q
    opts.tol=16*eps;
    [uu ss vv] = lansvd(Y,q,'L',opts);
    D=uu(:,1:q);
    P=ss(1:q,1:q)*vv(:,1:q)';
else
    D = eye(size(Y,1));
    P = Y;
end
tU= P*X'/(XXt + lambda*I);
mX=-tU(:,end);
U=tU(:,1:end-1);


