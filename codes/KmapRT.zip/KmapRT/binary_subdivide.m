function [V ploc b]=binary_subdivide(X,Y,depth,tol,subtype)
% function [V ploc b]=binary_subdivide(X,Y,depth,tol,subtype);
% Create the binary tree stucture by subdividing X w.r.t. Y
%
% Input:
%     X        -    a dxn matrix; data points as in columns
%     Y        -    a pxn matrix; data responses as in columns
%     depth    -    a scaler; the depth of the tree structure (not including the root)
% Optional Input:
%     tol      -    a scaler; default is 0.0001 (can be adapted to the data's scale)
%     subtype  -    binary; 1 (default) creates randomized tree; 0 creates
%              deterministic tree.
%
%
% Output:
%     V        -    a dx( 2^(depth)-1 ) matrix; the directions (as in columns) of hyperplanes for the subdivision
%     b        -    a 1x( 2^(depth)-1 ) vector; the offset values of hyperplanes for the subdivision
%                   (the hyperplane is v^T * x - b = 0)
%     ploc     -    a 1x( 2^(depth+1)-1 ) matrix; stores the tree structure; 
%     

if ~exist('subtype','var');
    subtype=1;
end


[~,N]=size(Y);


startlist=0;
stoplist=N;
thisnode=1;

vcount=0;% index into decision matrix
tcount=1;%total number of nodes
lcount=0;%number of leaves
% subtype
for k=1:depth
    ccount=0;% number of fertile nodes at this level
    if length(startlist)<1
        return
    end
    
    tstartlist=[];
    for j=1:length(startlist)
        tN=stoplist(j)-startlist(j);
        tY=Y(:,startlist(j)+1:stoplist(j));
        tX=X(:,startlist(j)+1:stoplist(j));
        ty=tY-mean(tY,2)*ones(1,tN);
        
        %tw=split_Y_via_linear_X(tX,ty,.0001);
        if subtype==0
            [~,~,vv]=svd(ty*tX');
            tw=vv(:,1);
        else
            rid=ceil(rand*tN);
            ty1=ty(:,rid);
            clear dists;
            dists(1,:)=sqrt(sum((ty-ty1*ones(1,tN)).^2));
            id=samplefromd(dists(1,:)/sum(dists(1,:)));
            ty2=ty(:,id);
            for s=1:10
                dists(1,:)=sqrt(sum((ty-ty1*ones(1,tN)).^2));
                dists(2,:)=sqrt(sum((ty-ty2*ones(1,tN)).^2));
                [~,minc]=min(dists);
                ty1=mean(ty(:,minc==1),2);
                ty2=mean(ty(:,minc==2),2);
            end
            df=ty1-ty2;
            tw=tX*(df'*ty)';
        end
        
        a=tw'*tX;
        tb=median(a);
        
        pid=find(a>tb);                 nid=find(a<=tb);
        rp=tY(:,pid);                    rn=tY(:,nid);
        erp=max(sum((rp-mean(rp,2)*ones(1,length(pid))).^2));
        ern=max(sum((rn-mean(rn,2)*ones(1,length(nid))).^2));
        id=[nid pid];
        
        X(:,startlist(j)+1:stoplist(j))=tX(:,id);
        Y(:,startlist(j)+1:stoplist(j))=tY(:,id);
        
        bigchildid=tcount+2;             smallchildid=tcount+1;
        ploc(1,thisnode(j))=tcount+1;%bigger ip goes second, smaller goes first.
        ploc(2,thisnode(j))=tcount+2;
        tcount=tcount+2;
        
        vcount=vcount+1;
        ploc(3,thisnode(j))=vcount;
        %V(:,vcount)=tw(1:end-1);
        V(:,vcount)=tw;
        %        b(vcount)=-tw(end);
        b(vcount)=tb;
        
        %fprintf('%f %f %d %d\n',length(find(V(:,vcount)'*tx>b(vcount))),length(find(V(:,vcount)'*tx<b(vcount))),k,j);
        
        %        erp
        
        if ((ern>tol)&&(k<depth)&&(length(nid)>10))
            ccount=ccount+1;
            tstartlist(ccount)=startlist(j);
            tstoplist(ccount)=startlist(j)+length(nid);
            temp_thisnode(ccount)=smallchildid;
        else
            lcount=lcount+1;
            %tcount=tcount+1;
            ploc(1,smallchildid)=-lcount;
            ploc(2,smallchildid)=-lcount;
            ploc(3,smallchildid)=-lcount;
        end
        if ((erp>tol)&&(k<depth)&&(length(pid)>10))
            ccount=ccount+1;
            tstartlist(ccount)=startlist(j)+length(nid);
            tstoplist(ccount)=stoplist(j);
            temp_thisnode(ccount)=bigchildid;
        else
            lcount=lcount+1;
            %tcount=tcount+1;
            ploc(1,bigchildid)=-lcount;
            ploc(2,bigchildid)=-lcount;
            ploc(3,bigchildid)=-lcount;
        end
        
    end
    startlist=tstartlist;
    stoplist=tstoplist;
    thisnode=temp_thisnode;
    %refine maps with fixed domains here?
end





function id=samplefromd(d);
%samples from density d
u=cumsum(d);
tu=u-rand;
tu(tu<0)=inf;
[~, id]=min(tu);


