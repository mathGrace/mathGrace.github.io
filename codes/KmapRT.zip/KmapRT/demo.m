% this example is just to show the usage of the code, but not well designed
% as a regression problem.
X = randn(5,200);
Y = randn(4,200);

K = 4; l = 3; r = 2;
subtype = 1;

% Require the package PROPACK http://sun.stanford.edu/~rmunk/PROPACK/
addpath F:\Dropbox\Research\useful_codes\apg_partial\apg_partial\PROPACK\


[U D mX mY V ploc b mp]=main_regress_tree_kqf(X,Y,K,r,l,10,.001,.01,subtype);
Yhat = predict_regress_tree_kqf(X, U, D, mX, mY, V, ploc, b, mp);

fprintf('relative error is %.2f \n',norm(Yhat-Y,'fro')/norm(Y,'fro'))