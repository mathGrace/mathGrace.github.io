function p=binary_fprop_dumb(X,V,b,ploc)
% function p=binary_fprop_dumb(X,V,b,ploc);
% assign each of the data point in X to a leaf node of the tree defined by
% V,b,ploc




[~, N]=size(X);
p=zeros(N,1);
for k=1:N
    c=1;
	current_node=1;
    x=X(:,k);
    while (c) 
        offb=ploc(3,current_node);
        if (offb>0)
            a=x'*V(:,offb);
            if (a > b(offb))
                current_node=ploc(2,current_node);	
            else 
                current_node=ploc(1,current_node);	
            end
        else
            c=0;
            p(k)=-offb;
        end
    end
        
end
