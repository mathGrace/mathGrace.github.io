function rY = predict_regress_tree_kqf(X, U, D, mX, mY, V, ploc, b, mp)
% function rY = predict_regress_tree_kqf(X, U, D, mX, mY, V, ploc, b, mp)
% Estimate the response Y for X based on the (tree+k q-flats)regression model



p=binary_fprop_dumb(X,V,b,ploc);
[pb plid]=mvi(p);
for k=1:length(plid)
    tx=X(:,plid{k});
    tp=mp(pb(k));
     P=bsxfun(@minus,U{tp}*tx,mX(:,tp));
     tr=bsxfun(@plus,D{tp}*P,mY(:,tp));
     rY(:,plid{k})=tr;
end