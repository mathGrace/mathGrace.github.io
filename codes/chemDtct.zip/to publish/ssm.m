function [T1 T2] = ssm(data, signature, bck_mask, bck_dim, bck_basis, bck_ctr, bck_method)
% single folder
% [T1 T2] = ssm(data, signature, bck_mask, bck_dim, bck_method)
% Statistics derived from SubSpace Model for detectiong chemical plumes.
% 
% Inputs
% data           - NxD
% signature      - Dx1
% bck_mask       - a 0-1 vector of length N
% bck_dim        - an integer, dimension of the subspace for the background 
% bck_method     - method to compute the subspace for the background; default (pca)
% bck_basis      - Dxd, d=bck_dim.
% bck_ctr        - Dx1
% Outputs
% T1             - Nx1 vector, detection-results, GLRT (generalized likelihood ratio test) with variance known.
% T2             - Nx1 vector, detection-results, GLRT with variance unknown.
%  
% written by Yi (Grace) Wang, yiwang@math.duke.edu
% reference - Dimitris G. Manolakis, Steven E. Golowich, and Robert S. DiPietro. 
%                             Signal Processing for Hyperspectral Remote Sensing of Chemical Clouds


if ~exist('bck_dim','var')
    bck_dim = 1;
end

if ~exist('bck_method','var')
    bck_method = 'pca';
end

if ~exist('bck_mask','var')
    bck_mask = ones(size(data,1),1);
end

if ~exist('bck_basis','var')
    bck_basis = [];
end

% background modeling
bck_mask = logical(bck_mask);
if numel(bck_mask) ~= size(data,1)
    error('The background mask should contain one entry for every pixel.');
end
data_bck = data(bck_mask,:);
switch bck_method
    case 'pca'
        % Applying principal component analysis
        ctr = mean(data_bck,1);
        [~,~,v] = svd( data_bck - repmat(ctr,size(data_bck,1),1) , 0 );
        B = v(:,1:bck_dim);
        %     case 'rpca'
        %         G = mpccppro_relax(data_bck,opts.lambda,opts.maxiter,opts.mu,opts.maxr);
        %         ctr = mean(G,1);
        %         [~,~,v] = svd( G - repmat(ctr,size(G,1),1) , 0 );
        %         B = v(:,1:bck_dim);
    case 'given'
        ctr = bck_ctr;
        B = bck_basis(:,1:bck_dim);
end

data0 = data - repmat(ctr,size(data,1),1);
% computing the test statistic
X2 = sum(data0 .^ 2, 2);
A = [signature B];
AtA = A' * A;
XA = data0 * A;
PtbX = AtA \ (A');
PtbX = XA*PtbX;

if isempty(B)
    t1 = X2;
%     signature'*v(:,1:10)
else
    t1 = X2 - sum( (data0*B) .^ 2 , 2 );
end
t2 = X2 - sum( PtbX .^ 2 , 2 );

T1 = t1 - t2;
T2 = t1 ./ t2;
