function index_outlier = app_lv_sc(data,rho)
% index_outlier = app_lv_sc(data,rho)
% This function detects outliers of portion rho from the largest leverage scores.
% Inputs
% data  - NxD
% rho   - pertentage of outliers
%
% Output
% index_outlier  - Nx1, logical, true (an outlier); false (not an outlier)
index_outlier = true(size(data,1),1);
[U,~,~]=svd(data,0);
lv_sc = sum(U.^2,2);
[~,index] = sort(lv_sc(:));
thresh = floor(rho*size(data,1));
index_outlier(index(1:end-thresh)) = false;




