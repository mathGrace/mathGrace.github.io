clear
% Load the hyperspectral data
DATA_PKG = 'dugway_embedded_tep_200_ppmm';
load(['F:\Dropbox\Research\Mauro\MIT_Challenge\Data\',DATA_PKG])

% Apply a segmentation algorithm to obtain K classes of pixels.
load(['F:\Dropbox\Research\Mauro\MIT_Challenge\',DATA_PKG,'_seg_lbf_affine_inlier'])
% load(['/ytmp/LargeData/MIT_Challenge/Data/',DATA_PKG])
% load(['/ytmp/LargeData/MIT_Challenge/' DATA_PKG,'_seg_lbf_affine_inlier'])
labels = mincent_data_inlier;  % K=3.

% Set up parameters
bck_dim = 1;  % background dimension
outlierType = 'leverageScore';  % detect outliers by leverage scores
detctType = 'ssm';  % detect chemicals by the mixture linear coefficients.
boost_n = 0;  % number of times of applying resamplying procedure
plsr_d = 4;   % dimension of partial least square regression
rho = 0.005;  % portion of outliers to be detected
verbose = 0;  % showing a picture of variance explained by PLS components

%% A single cube
[y im] = chmDetct(data,cube,sig,labels,bck_dim,outlierType,detctType,boost_n,plsr_d,rho,verbose);

% showing the detection map
figure,
imagesc(im)
colorbar

%% A sequence of cubes (a movie)