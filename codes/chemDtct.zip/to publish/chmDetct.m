function [y im] = chmDetct(data,cube,sig,labels,bck_dim,outlierType,detctType,boost_n,plsr_d,rho,verbose)
% Inputs
% data    - hyperspectral data, NxD
% cube    - hyperspectral data, mxnxD  (N=mn)
% sig     - chemical absorption coefficients, 1xd
% labels  - labels in 1,2,3,..., Nx1
% bck_dim - background dimension
% detctType - string variable for choosing detection algorithm; options are
%             'ace' (Gaussian model),'ssm' (subspace model),'LinMix' (mixture linear coefficients)
% outlierType - string variable for choosing outlier detection methods;
%             options are 'leverageScore',
% boost_n - times for running the resampling procedure, i.e., choose a few
%           pixels most likely to be background and their spatial neighbors for
%           background and rerun the detection algorithm; when 0, no
%           resampling procedure is taken.
% plsr_d  - dimension for partial least square regression (plsr); default is 5
% rho     - the portion of outliers to be detected
% verbose - when 1, figures of variance in plsr and the output detection
%           maps are shown; when 0, no figures
%
% Outputs
% y - detection map, Nx1
% im - detection map, mxn
%% remove outliers
if ~exist('bck_dim','var')
    bck_dim = 1;
end

if ~exist('rho','var')
    rho = 0.005;
end

if ~exist('plsr_d','var')
    plsr_d = 5;
end

if ~exist('outlierType','var')
    outlierType = 'leverageScore';
end

switch outlierType
    % detecting outliers by leverage score
    case 'leverageScore'
        data_input = data;
        index_outlier = app_lv_sc(data_input,rho);
end

%% Setting up parameters...
bck_mask = ~index_outlier;
labels(index_outlier) = 0;
y = zeros(size(data,1),1);

thresh1 = 0.2;  % threshold for boosting
thresh2 = 0.15; % threshold for plsr

l = 20;  % dimension for plotting plsr variances

%% Applying Detection Algorithm
for i = 1:max(labels)
    idx = find(labels==i);
    tmp_mask = bck_mask(idx);
    
    y(idx) = app_detct(data(idx,:),sig,tmp_mask,bck_dim,detctType);
    
    % Applying resampling procedure boost_n times.
    for jj = 1:boost_n
        % bck from bottom thresh and their 4 nearest spatial neighbors.
        new_mask = boost_mask(y(idx),idx,cube,4,thresh1);
        tmp_mask = new_mask(idx);
        y(idx,jj) = app_detct(data(idx,:),sig,tmp_mask,bck_dim,detctType);
    end
end

% Applying plsr
if plsr_d > 0
    y = boost_pls(data,y,thresh2,plsr_d);
    if verbose
        [~, ~, ~,~,~,~,~,~,PCTVAR,~] = boost_pls(data,y,thresh2,l);
        figure
        plot(1:l,cumsum(100*PCTVAR(2,:)),'-bo');
        xlabel('Number of PLS components');
        ylabel('Percent Variance Explained');
    end
end

im = reshape(y,size(cube,1),size(cube,2));
end

