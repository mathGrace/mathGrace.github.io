function [newY1, newX, newY, XL,YL,XS,YS,BETA,PCTVAR,MSE] = boost_pls(X,y,rho,l,lambda)
% [newY1, newX, newY, XL,YL,XS,YS,BETA,PCTVAR,MSE] = boost_pls(X,y,rho,l,lambda)
% This function applies partial least square regression to a selected
% portion of (X,y), where X is the data matrix and y is the response
% (detection score from a detection algorithm).
% A portion rho of background pixels and rho of chemical pixels are
% selected according to y.
%
%
% Inputs
% X  - NxD
% y  - Nx1
% rho - a portion, <1/2.
% l  - dimension for plsr
% lambda - regularization parameter, default 1e-6.
%
% Output
% newY1 - Nx1, the new projected response, can be used as detection score.
% [XL,YL,XS,YS,BETA,PCTVAR,MSE] = plsregress(slctX,slctY,l); refer to the help function of the built-in matlab function plsregress.m  
if ~exist('lambda','var')
    lambda = 1e-6;
end

[~,index] = sort(y);
n = floor(size(X,1)*rho);
idx = [index(1:n);index(end-n+1:end)];
idx = idx(:);
X0 = X-repmat(mean(X),size(X,1),1);
y0 = y-mean(y);
slctX = X0(idx,:);
slctY = y0(idx);
[XL,YL,XS,YS,BETA,PCTVAR,MSE] = plsregress(slctX,slctY,l);

newX = X0*XL/(XL'*XL+lambda*eye(l));
newX = newX*XL';
newY = y0*YL/(YL'*YL+lambda*eye(l));
newY = newY*YL';

newY1 = [ones(size(X,1),1) X]*BETA;

end