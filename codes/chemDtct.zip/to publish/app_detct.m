function y = app_detct(data,sig,bck_mask,bck_dim,detctType)
% y = app_detct(x,sig,tmp_mask,bck_dim,detctType)
% This function applies a detection algorithm to data.
% Inputs
% data       - hyperspectral data, NxD
% sig        - chemical absorption coefficients, 1xd
% bck_mask   - a 0-1 vector of length N
% bck_dim    - background dimension
% detctType  - string variable for choosing detection algorithm; options are
%             'ace' (Gaussian model),'ssm' (subspace model),'LinMix' (mixture linear coefficients)

% Outputs
% y - detection map, Nx1

switch detctType
    case 'ssm'
        % subspace models
        [~, y] = ssm(data, sig', bck_mask, bck_dim, 'pca');
    case 'ace'
        % Gaussian models
        % function ace.m is required for using the adaptive cosine estimator.
        % reference - Dimitris G. Manolakis, Steven E. Golowich, and Robert S. DiPietro.
        %     Signal Processing for Hyperspectral Remote Sensing of Chemical Clouds
        [y, ~] = ace(data, sig, bck_mask);
    case 'LinMix'
        % mixture linear coefficients
        LinCoeff = LMix(data,bck_dim,sig,bck_mask, 'pca', [],[]);
        y = -LinCoeff;
end
