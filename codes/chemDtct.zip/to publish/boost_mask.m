function new_mask = boost_mask(score,idx,cube,k,thresh)
% new_mask = boost_mask(score,idx,cube,k,thresh)
% This function recognizes a portion of thresh pixels as background from bottom of the score values, as well as their spatial neighbors.
%      the new mask for background is saved in new_mask.
% Inputs
% score  - Nx1, detection score, an output from a detection algorithm, the
%              greater, the more likely the pixel is a chemical.
% idx    - the indices of pixels under consideration (their detection scores are as in the variable score) in the original cube.
% cube   - hyperspectral data, mxnxD  (N=mn)
% k      - the number of spatial neighbors to be chosen, default is 4.
% thresh - the portion of background pixels to be recognized, no greater
%                     than 1/(1+k).
%
% Output
% new_mask - Nx1, logical, mask for background.

[~,index] = sort(score,'ascend');
valid_idx = idx(index(1:floor(thresh*length(score))));
mask = zeros(size(cube,1),size(cube,2));
mask(valid_idx) = 1;
new_mask = mask;
for i=1:size(mask,1)
    for ii=1:size(mask,2)
        if mask(i,ii)==1
            switch k
                case 4
                    t1 = max(i-1,1); t2 = max(ii-1,1);
                    t3 = min(i+1,size(mask,1)); t4 = min(ii+1,size(mask,2));
                    new_mask(i,t2) = 1;
                    new_mask(i,t4) = 1;
                    new_mask(t1,ii) = 1;
                    new_mask(t3,ii) = 1;
            end
        end
    end
end
new_mask=logical(new_mask(:));