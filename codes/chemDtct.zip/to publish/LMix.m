function dec_temp = LMix(data,bck_dim,sig,bck_mask,bck_method,bck_basis,bck_ctr)
% dec_temp = LMix(data,bck_dim,sig,bck_mask,bck_method,bck_basis,bck_ctr)
% This function applies the linear mixture method.
% Inputs
% data           - NxD
% sig            - Dx1
% bck_mask       - a 0-1 vector of length N
% bck_dim        - an integer, dimension of the subspace for the background 
% bck_method     - method to compute the subspace for the background; default (pca)
% bck_basis      - Dxd, d=bck_dim.
% bck_ctr        - Dx1
% 
% Output
% dec_temp       - Nx1 vector, detection statistic.


data_back = data(bck_mask,:);
switch bck_method
    case 'pca' 
        ctr = mean(data_back);
        data_back0 = data_back - repmat(ctr,size(data_back,1),1);
        [~,~,V] = svd(data_back0,0);
    case 'given'
        ctr = bck_ctr;
        V = bck_basis;
end

Sig1 = [sig;V(:,1:bck_dim)';ones(1,length(sig))];
SSt = Sig1*Sig1';
YSt = data * Sig1';
% YSt = ( data - repmat(ctr,size(data,1),1) ) * Sig1';
AlphaBeta = YSt / SSt;
dec_temp = AlphaBeta(:,1);
