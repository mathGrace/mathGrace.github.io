%% This is the main script that generates all the figures in the following paper:
% " Consistency and Convergence Rate for Nearest Subspace Classifier ", 
% to appear in Information and Inference: A Journal of the IMA.

% Author: Yi (Grace) Wang; Email: ywang392@syr.edu
%% Specify plotting parameters
clear
cols = {'ob--','*k:','sg-','^r-.'};
ftsz = 22;
mksize = 12;
%% Generating Fig 1a
load('Fig1a') % If using the provided simulation results
% run dataGeneration_Fig1a.m here and comment the previous line if want to generate the data by yourself
sortErr=sort(Errn-ErrStar,2);
Err = [sortErr(:,1) sortErr(:,floor(ss*.25)) sortErr(:,floor(ss*.50)) sortErr(:,floor(ss*.75))];
hf = figure;
for tt = 1:size(Err,2)
    plot(sqrt(2*ns'),Err(:,tt),cols{tt},'LineWidth',2,'MarkerSize',mksize),hold on
end
axis tight
set(gca,'fontsize',ftsz)
legend('minimum','25% pertcentile','median','75% pertcentile')
xlabel('$$\sqrt{n}$$','Interpreter','latex')
ylabel('R_n - R^*')
saveas(hf,'Fig1a.eps','epsc')
%% Generating Fig 1b
load('Fig1b') % If using the provided simulation results
% run dataGeneration_Fig1b.m here and comment the previous line if want to generate the data by yourself
sortErr=sort(Errn,2);
Err = [sortErr(:,1) sortErr(:,floor(ss*.25)) sortErr(:,floor(ss*.50)) sortErr(:,floor(ss*.75))];
hf = figure;
for tt = 1:size(Err,2)
    plot((2-sigmas)./2,Err(:,tt)-ErrStar,cols{tt},'LineWidth',2,'MarkerSize',mksize),hold on
end
axis tight
set(gca,'fontsize',ftsz)
xlabel('\delta_d')
ylabel('R_n - R^*')
set(gca,'fontsize',22)
legend('minimum','25% percentile','median','75% percentile')
saveas(hf,'Fig1b.eps','epsc')
%% Generating Fig 2a
load('Fig2a') % If using the provided simulation results
% run dataGeneration_Fig2a.m here and comment the previous line if want to generate the data by yourself
sortErr=sort(Errn,2);
Err = [sortErr(:,1) sortErr(:,floor(ss*.25)) sortErr(:,floor(ss*.50)) sortErr(:,floor(ss*.75))];
hf = figure;
for tt = 1:size(Err,2)
    plot(Ds,Err(:,tt)-ErrStar,cols{tt},'LineWidth',2,'MarkerSize',mksize),hold on
end
axis tight
set(gca,'fontsize',ftsz)
xlabel('D')
ylabel('R_n - R^*')
set(gca,'fontsize',22)
legend('minimum','25% percentile','median','75% percentile')
saveas(hf,'Fig2a.eps','epsc')
%% Generating Fig 2b
load('Fig2b') % If using the provided simulation results
% run dataGeneration_Fig2b.m here and comment the previous line if want to generate the data by yourself
sortErr=sort(Errn,2);
Err = [sortErr(:,1) sortErr(:,floor(ss*.25)) sortErr(:,floor(ss*.50)) sortErr(:,floor(ss*.75))];
hf = figure;
for tt = 1:size(Err,2)
    plot(dds,Err(:,tt)-ErrStar,cols{tt},'LineWidth',2,'MarkerSize',mksize),hold on
end
axis tight
set(gca,'fontsize',ftsz)
xlabel('d')
ylabel('R_n - R^*')
set(gca,'fontsize',22)
legend('minimum','25% percentile','median','75% percentile')
saveas(hf,'Fig2b.eps','epsc')
%% Generating Fig 3a
load('Fig3a') % If using the provided simulation results
% run dataGeneration_Fig3a.m here and comment the previous line if want to generate the data by yourself
sortErr=sort(Errn-ErrStar,2);
Err = [sortErr(:,1) sortErr(:,floor(ss*.25)) sortErr(:,floor(ss*.50)) sortErr(:,floor(ss*.75))];
hf = figure;
for tt = 1:size(Err,2)
    plot(sqrt(2*ns'),Err(:,tt),cols{tt},'LineWidth',2,'MarkerSize',mksize),hold on
end
axis tight
set(gca,'fontsize',ftsz)
legend('minimum','25% pertcentile','median','75% pertcentile')
xlabel('$$\sqrt{n}$$','Interpreter','latex')
ylabel('R_n - R^*')
saveas(hf,'Fig3a.eps','epsc')
%% Generating Fig 3b
load('Fig3b') % If using the provided simulation results
% run dataGeneration_Fig3b.m here and comment the previous line if want to generate the data by yourself
sortErr=sort(Errn-ErrStar,2);
Err = [sortErr(:,1) sortErr(:,floor(ss*.25)) sortErr(:,floor(ss*.50)) sortErr(:,floor(ss*.75))];
hf = figure;
for tt = 1:size(Err,2)
    plot(sqrt(4*ns'),Err(:,tt),cols{tt},'LineWidth',2,'MarkerSize',mksize),hold on
end
axis tight
set(gca,'fontsize',ftsz)
legend('minimum','25% pertcentile','median','75% pertcentile')
xlabel('$$\sqrt{n}$$','Interpreter','latex')
ylabel('R_n - R^*')
saveas(hf,'Fig3b.eps','epsc')