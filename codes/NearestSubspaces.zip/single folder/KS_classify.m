function [testLabels, groupBases, ctrX] = KS_classify(trainX, trainClass, subspaceDimensions, testX, IsAffine)
% function [testLabels, groupBases, ctrX] = KS_classify(trainX, trainClass, subspaceDimensions, testX, IsAffine)
% computes the nearest subspace classifier and classifies the testing data.
%
%
% Inputs:
%     trainX               -    A DxN matrix, the training data, represented as columns.
%     trainClass           -    A 1xN vector, the labels of the training data. 
%     subspaceDimensions   -    A 1xK vector, the i-th entry is the intrinsic dimension for the i-th subspace.
%     testX                -    A DxM matrix, the testing data, represented as columns.
%     IsAffine             -    (Optional) A scalar, 0 or 1; the default value is 1
%                                0 - means linear subspaces, 1 - means affine subspaces.
%
% Outputs:
%     testLabels           -    A 1xM vector, the labels of the testing data
%     groupBases           -    A 1xK cell, the i-th cell element is a Dxd matrix representing the othorgnal basis for the i-th subspace, 
%                               where d is the intrinsic dimension for the i-th subspace.
%     ctrX                 -    A DxK matrix, the i-th column is the center of the i-th subspace
% 
% 
% Reference: " Consistency and Convergence Rate for Nearest Subspace Classifier ", 
% to appear in Information and Inference: A Journal of the IMA.
% Author: Yi (Grace) Wang; Email: ywang392@syr.edu

if nargin < 5
    IsAffine = 1;
end


K = length(subspaceDimensions);
groupBases = cell(1,K);
distances = zeros(K,size(testX,2));
ctrs = zeros(size(testX,1),K);

if IsAffine
    
    % Learning the center and basis for the subspaces from labeled training data
    for i = 1:K
        d = subspaceDimensions(i);
        newX = trainX(:,trainClass==i);
        ctrs(:,i) = mean(newX,2);
        ctrX = newX - repmat(ctrs(:,i),1,size(newX,2));
        [~,~, V] = svd(ctrX',0);
        groupBases{i} = V(:,1:d);
    end
    
    % Compute the point to subspace distances for the testing data
    for subspaceIndex=1:length(subspaceDimensions)
        ctrX = testX - repmat(ctrs(:,subspaceIndex),1,size(testX,2));
        distances(subspaceIndex,:)=point_to_space_distance(ctrX,groupBases{subspaceIndex});
    end
    
else
    
    % Learning the center and basis for the subspaces from labeled training data
    for i = 1:length(subspaceDimensions)
        d = subspaceDimensions(i);
        newX = trainX(:,trainClass==i);
        [~,~, V] = svd(newX',0);
        groupBases{i} = V(:,1:d);
    end
    
    % Compute the point to subspace distances for the testing data
    for subspaceIndex=1:length(subspaceDimensions)
        distances(subspaceIndex,:)=point_to_space_distance(testX,groupBases{subspaceIndex});
    end
    
end

% Finding the labels of testing data from the distances
[~, testLabels] = min(distances);

end

function distances = point_to_space_distance(centeredData,subspaceBasis)
% function distances = point_to_space_distance(centeredData,subspaceBasis)
%
% Computes the Euclidean distance between one or more vectors and a subspace.
%
% Inputs:
%   centeredData -  The samples to be projected, represented as columns.
%
%   subspaceBasis - The basis for the subspace to project onto; each column
%                   is a basis vector.
%
% Output:
%   distances -  A row vector of distances between the points and
%                           the subspace.

dataLengths2 = sum( centeredData .^ 2 );
perpDistances2 = sum ( (subspaceBasis' * centeredData) .^ 2, 1 );
distances = sqrt( dataLengths2 - perpDistances2 );
end



