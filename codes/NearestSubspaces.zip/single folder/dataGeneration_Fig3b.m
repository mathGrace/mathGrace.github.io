%% Specify parameters
K = 2; D = 3; d = 1;
N = 10000; ss = 100;
ns = [5:5:50 60:20:200 300:100:1000];
sigma = .5;
mu1 = [1,1,1]'; 
mu2 = [-1,-1,-1]';
Sigma1 = diag([2,sigma,sigma]); 
R = randn(D); R = orth(R);
Sigma2 = R*Sigma1*R';
Errn = zeros(length(ns),ss);
%% Generate N samples for computing expectation
Y = [ones(1,N),2*ones(1,3*N)];
X1 = mvnrnd(mu1,Sigma1,N);
X2 = mvnrnd(mu2,Sigma2,3*N);
X = [X1',X2'];
%% Compute the result of Bayes classifier
p1 = mvnpdf(X',mu1',Sigma1);
p2 = mvnpdf(X',mu2',Sigma2);
Ystar = ones(length(Y),1);
Ystar(p2>p1) = 2;
ErrStar = sum(Ystar~=Y') / (length(Y));
%% Generate n=K*nk samples for training %% Applying the NSS algorithm
for ii = 1:length(ns)
    nk = ns(ii);
    for jj = 1:ss
        yn = [ones(1,nk),2*ones(1,3*nk)];
        xn1 = mvnrnd(mu1,Sigma1,nk);
        xn2 = mvnrnd(mu2,Sigma2,3*nk);
        xn = [xn1',xn2'];
        
        [testLabels groupBases ctrX] = KS_classify(xn, yn, d*ones(1,K), X);
        Errn(ii,jj) = sum(testLabels~=Y) / (length(Y));
    end
end
save('Fig3b','Errn','ss','ns','ErrStar')
