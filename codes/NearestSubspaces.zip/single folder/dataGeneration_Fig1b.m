%% Specify parameters
K = 2; D = 3; d = 1;
N = 20000; ss = 100;
sigmas = [0.01 0.05 0.1:0.1:0.8];
nk = 1000;
mu1 = [1,1,1]'; 
mu2 = [-1,-1,-1]';

R = randn(D); R = orth(R);

Errn = zeros(length(sigmas),ss);
ErrStar = zeros(length(sigmas),1);
%% Generate n=K*nk samples for training %% Applying the NSS algorithm
for ii = 1:length(sigmas)
    sigma = sigmas(ii);
    Sigma1 = diag([2,sigma,sigma]); 
    Sigma2 = R*Sigma1*R';
    %% Generate N samples for computing expectation
    Y = [ones(1,N),2*ones(1,N)];
    X1 = mvnrnd(mu1,Sigma1,N);
    X2 = mvnrnd(mu2,Sigma2,N);
    X = [X1',X2'];
    %% Compute the result of Bayes classifier
    p1 = mvnpdf(X',mu1',Sigma1);
    p2 = mvnpdf(X',mu2',Sigma2);
    Ystar = ones(2*N,1);
    Ystar(p2>p1) = 2;
    ErrStar(ii) = sum(Ystar~=Y') / (2*N);
    for jj = 1:ss
        yn = [ones(1,nk),2*ones(1,nk)];
        xn1 = mvnrnd(mu1,Sigma1,nk);
        xn2 = mvnrnd(mu2,Sigma2,nk);
        xn = [xn1',xn2'];
        
        [testLabels groupBases ctrX] = KS_classify(xn, yn, d*ones(1,K), X);
        Errn(ii,jj) = sum(testLabels~=Y) / (2*N);
    end
end
save('Fig1b','Errn','ss','sigmas','ErrStar')
