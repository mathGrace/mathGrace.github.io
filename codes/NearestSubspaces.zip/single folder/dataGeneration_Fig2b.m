%% Specify parameters
clear
K = 2;
dds = 1:8;
D = 20;

mu1 = ones(D,1);
mu2 = mu1; mu2(1:3) = mu1(1:3) - 2;
R = randn(D); R = orth(R);

N = 20000; ss = 100;
sigma = .5;
nk = 1000;

Errn = zeros(length(dds),ss);
ErrStar = zeros(length(dds),1);
%% Generate n=K*nk samples for training %% Applying the NSS algorithm
for ii = 1:length(dds)
    d = dds(ii);

    Sigma1 = diag([2*ones(1,d),sigma*ones(1,D-d)]);
    Sigma2 = R*Sigma1*R';
    %% Generate N samples for computing expectation
    Y = [ones(1,N),2*ones(1,N)];
    X1 = mvnrnd(mu1',Sigma1,N);
    X2 = mvnrnd(mu2',Sigma2,N);
    X = [X1',X2'];
    %% Compute the result of Bayes classifier
    p1 = mvnpdf(X',mu1',Sigma1);
    p2 = mvnpdf(X',mu2',Sigma2);
    Ystar = ones(2*N,1);
    Ystar(p2>p1) = 2;
    ErrStar(ii) = sum(Ystar~=Y') / (2*N);
    for jj = 1:ss
        yn = [ones(1,nk),2*ones(1,nk)];
        xn1 = mvnrnd(mu1',Sigma1,nk);
        xn2 = mvnrnd(mu2',Sigma2,nk);
        xn = [xn1',xn2'];
        
        [testLabels groupBases ctrX] = KS_classify(xn, yn, d*ones(1,K), X);
        Errn(ii,jj) = sum(testLabels~=Y) / (2*N);
    end
end

save('Fig2b','Errn','ss','dds','ErrStar')
