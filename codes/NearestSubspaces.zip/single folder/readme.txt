This package contains the scripts which generate all the figures in the following paper:
" Consistency and Convergence Rate for Nearest Subspace Classifier ", 
to appear in Information and Inference: A Journal of the IMA.

Author: Yi (Grace) Wang; Email: ywang392@syr.edu

A list of all the files:

-----------------------------------------------------------------------------------------------------------
MAINplotAllFigures.m        --    The main script that generates all the figures

-----------------------------------------------------------------------------------------------------------
KS_classify.m               --    The main function implementing the nearest subspace classifier

-----------------------------------------------------------------------------------------------------------
Fig1a.mat                   --    The generated data for plotting Fig1a.
Fig1b.mat                   --    The generated data for plotting Fig1b.
Fig2a.mat                   --    The generated data for plotting Fig2a.
Fig2b.mat                   --    The generated data for plotting Fig2b.
Fig3a.mat                   --    The generated data for plotting Fig3a.
Fig3b.mat                   --    The generated data for plotting Fig3b.

-----------------------------------------------------------------------------------------------------------
dataGeneration_Fig1a.m      --    The script that generates data for plotting Fig1a and overwrites Fig1a.mat.
dataGeneration_Fig1b.m      --    The script that generates data for plotting Fig1b and overwrites Fig1b.mat.
dataGeneration_Fig2a.m      --    The script that generates data for plotting Fig2a and overwrites Fig2a.mat.
dataGeneration_Fig2b.m      --    The script that generates data for plotting Fig2b and overwrites Fig2b.mat.
dataGeneration_Fig3a.m      --    The script that generates data for plotting Fig3a and overwrites Fig3a.mat.
dataGeneration_Fig3b.m      --    The script that generates data for plotting Fig3b and overwrites Fig3b.mat.

