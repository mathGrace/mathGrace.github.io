function [B state] = amb_mfwmd_alternation1(M,A,W,L)

% state = amb_mfwmd_alternation(state[,m,n,r])
%
% Perform one iteration of the alternation algorithm. Provide all
% arguments for initialization of 'state' struct. The fields that are
% required to already exist are:
%
%   A, B, M, W, L, Lr
%
% Citation:
%
% See 'amb_mfwmd'

FUNCTION_NAME = 'amb_mfwmd_alternation1';

if nargin < 4
    L = 1e-10;
end

state.M = M;
state.A = A;
state.W = W;
state.L = L;

[m r] = size(A);
n = size(M,2);
state.B = zeros(n,r);

state.m = m;
state.n = n;
state.I_alt = state.L * eye(r,r);


% minimize

% improve B
for j=1:state.n
    % the diag matrix can be huge, so must avoid making it
    Wj = state.W(:,j).^2;
    AtWjWj = state.A';
    for i=1:state.m
        AtWjWj(:,i) = AtWjWj(:,i)*Wj(i);
    end
    state.B(j,:) = ( (AtWjWj*state.A + state.I_alt)\(AtWjWj*state.M(:,j)) )';
end

%     % improve A
%     for i=1:state.m
%         % the diag matrix can be huge, so must avoid making it
%         Wi = state.W(i,:).^2;
%         BtWiWi = state.B';
%         for j=1:state.n
%             BtWiWi(:,j) = BtWiWi(:,j)*Wi(j);
%         end
%         state.A(i,:) = ( (BtWiWi*state.B + state.I_alt)\(BtWiWi*state.M(i,:)') )';
%     end

%     sumsqrderr = amb_mfwmd_errfunc_sumsqrderr(state.A,state.B,state.M,state.W);
%     regerr = amb_mfwmd_errfunc_regularizeAB(state.A,state.B,state.Lr);
%     state.error = sumsqrderr + state.L*regerr;
B = state.B;
B = B';
end


