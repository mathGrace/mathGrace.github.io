function [opt_Y W states J status] = ALS_reg2(M,trustp,trank,OPTIONS)

% Track convergence status
[m n] = size(M);

if nargin < 4
    OPTIONS = struct();
end

if ~isfield(OPTIONS,'method')
    OPTIONS.method = 2;
end

if ~isfield(OPTIONS,'mu')
    OPTIONS.mu = rand(size(M));
end

if ~isfield(OPTIONS,'lambda3')
    OPTIONS.lambda3 = 1e-10;
end

if ~isfield(OPTIONS,'initer')
    OPTIONS.initer = 2;
end

if ~isfield(OPTIONS,'tol')
    OPTIONS.tol = 1e-3;
end

if ~isfield(OPTIONS,'tol1')
    OPTIONS.tol1 = 1e-4;
end

if ~isfield(OPTIONS,'tol2')
    OPTIONS.tol2 = 1e-6;
end

if ~isfield(OPTIONS,'maxiter')
    OPTIONS.maxiter = 5;
end

if ~isfield(OPTIONS,'A_type')
    OPTIONS.A_type = 1;
end

if ~ isfield(OPTIONS,'A')
    switch OPTIONS.A_type
        case 1
            OPTIONS.A = orth( randn(m,trank) );
        case 2
            [U S V] = svd(M);
            OPTIONS.A = U(:,1:trank);
    end
end

if ~isfield(OPTIONS,'B')
    OPTIONS.B = randn(n,trank);
end

if ~isfield(OPTIONS,'L')
    OPTIONS.L = 1e-7;
end

if ~isfield(OPTIONS,'M0')
    OPTIONS.M0 = M;
end

if ~isfield(OPTIONS,'W')
    OPTIONS.W = ones(size(M));
end

method = OPTIONS.method;
initer = OPTIONS.initer;
tol = OPTIONS.tol;
tol1 = OPTIONS.tol1;
tol2 = OPTIONS.tol2;
maxiter = OPTIONS.maxiter;
L = OPTIONS.L;
M0 = OPTIONS.M0;
lambda3 = OPTIONS.lambda3;
mu = OPTIONS.mu;

A = OPTIONS.A;
B = OPTIONS.B;
W = OPTIONS.W;

J(1) = Inf;
dif(1) = m*n;
dif1(1) = Inf;
dif2(1) = Inf;
k = 1;
bid = [];
switch method
    case 1
        while k <= maxiter && ( dif1(k)>1+tol1 || dif1(k)<1-tol1 ) && dif2(k) > tol2
            [A,B,states] = amb_mfwmd(A,B,M,W,'iterations',initer,'tolerance',tol);  %Damped Newton
            opt_Y = A * B';
            r = abs(opt_Y - M)+lambda3*mu;
            [sorted_r I] = sort(r(:));
            W = zeros(size(M));
            W(I(1:floor(trustp*numel(M)))) = 1;
            k = k+1;
            J(k) = sum(sorted_r(1:floor(trustp*numel(M))).^2);
            dif1(k) = J(k) / J(k-1);
            dif2(k) = abs( J(k) - J(k-1) );
            oldbid = bid;
            bid = I(1:floor(trustp*numel(M)));
            dif(k) = length(setdiff(bid,oldbid));
        end
        
    case 2
        while k <= maxiter && ( dif1(k)>1+tol1 || dif1(k)<1-tol1 ) && dif2(k) > tol2
            [A,B,states] = amb_mfwmd(A,B,M,W,'iterations',initer,'tolerance',tol,'algorithm','alternation','errors',1,'L',L);
            opt_Y = A * B';
            %             norm(opt_Y - M0,'fro')/norm(M0,'fro')
            r = abs(opt_Y - M)+lambda3*mu;
            [sorted_r I] = sort(r(:));
            W = zeros(size(M));
            W(I(1:floor(trustp*numel(M)))) = 1;
            k = k+1;
            J(k) = sum(sorted_r(1:floor(trustp*numel(M))).^2);
            dif1(k) = J(k) / J(k-1);
            dif2(k) = abs( J(k) - J(k-1) );
            oldbid = bid;
            bid = I(1:floor(trustp*numel(M)));
            dif(k) = length(setdiff(bid,oldbid));
        end
        
    case 3
        while k <= maxiter && ( dif1(k)>1+tol1 || dif1(k)<1-tol1 ) && dif2(k) > tol2
            [A,B,states] = amb_mfwmd(A,B,M,W,'iterations',initer,'tolerance',tol,'algorithm','altdn02','errors',1,'L',L); %Hybrid
            opt_Y = A * B';
            %             norm(opt_Y - M0,'fro')/norm(M0,'fro')
            r = abs(opt_Y - M)+lambda3*mu;
            [sorted_r I] = sort(r(:));
            W = zeros(size(M));
            W(I(1:floor(trustp*numel(M)))) = 1;
            k = k+1;
            J(k) = sum(sorted_r(1:floor(trustp*numel(M))).^2);
            dif1(k) = J(k) / J(k-1);
            dif2(k) = abs( J(k) - J(k-1) );
            oldbid = bid;
            bid = I(1:floor(trustp*numel(M)));
            dif(k) = length(setdiff(bid,oldbid));
        end
        
    case 4
        while k <= maxiter && ( dif1(k)>1+tol1 || dif1(k)<1-tol1 ) && dif2(k) > tol2
            [A,B,states] = amb_mfwmd(A,B,M,W,'iterations',initer,'tolerance',tol,'algorithm','dn altreg','errors',1,'L',L); %Hybrid
            opt_Y = A * B';
            %             norm(opt_Y - M0,'fro')/norm(M0,'fro')
            r = abs(opt_Y - M)+lambda3*mu;
            [sorted_r I] = sort(r(:));
            W = zeros(size(M));
            W(I(1:floor(trustp*numel(M)))) = 1;
            k = k+1;
            J(k) = sum(sorted_r(1:floor(trustp*numel(M))).^2);
            dif1(k) = J(k) / J(k-1);
            dif2(k) = abs( J(k) - J(k-1) );
            oldbid = bid;
            bid = I(1:floor(trustp*numel(M)));
            dif(k) = length(setdiff(bid,oldbid));
        end
        
    case 5
        while k <= maxiter && ( dif1(k)>1+tol1 || dif1(k)<1-tol1 ) && dif2(k) > tol2
            [A,B,states] = amb_mfwmd(A,B,M,W,'iterations',initer,'tolerance',tol,'algorithm','altdn03','errors',1,'L',L); %Hybrid
            opt_Y = A * B';
            %             norm(opt_Y - M0,'fro')/norm(M0,'fro')
            r = abs(opt_Y - M)+lambda3*mu;
            [sorted_r I] = sort(r(:));
            W = zeros(size(M));
            W(I(1:floor(trustp*numel(M)))) = 1;
            k = k+1;
            J(k) = sum(sorted_r(1:floor(trustp*numel(M))).^2);
            dif1(k) = J(k) / J(k-1);
            dif2(k) = abs( J(k) - J(k-1) );
            oldbid = bid;
            bid = I(1:floor(trustp*numel(M)));
            dif(k) = length(setdiff(bid,oldbid));
        end
end

if  ( dif1(k)<=1+tol1 && dif1(k)>=1-tol1 ) || dif2(k) <= tol2
    status = 1;
else
    status = 0;
end