function [Q, R] = grams(A)

% grams  Gram-Schmidt orthogonalization of the columns of A.
% The columns of A are assumed to be linearly independent.
%
% Q = grams(A) returns an m by n matrix Q whose columns are 
% an orthonormal basis for the column space of A.
%
% [Q, R] = grams(A) returns a matrix Q with orthonormal columns
% and an invertible upper triangular matrix R so that A = Q*R.
%
% Warning: For a more stable algorithm, use [Q, R] = qr(A, 0) .

[m, n] = size(A);
r = min(m,n);
Asave = A;
for j = 1:r
  for k = 1:j-1
      if A(:, k)'*A(:, k) < eps
          break
      end
    mult = (A(:, j)'*A(:, k)) / (A(:, k)'*A(:, k));
    A(:, j) = A(:, j) - mult*A(:, k);
  end
end
Q = A;
A(:,r+1:size(A,2)) = 0;
for j = 1:n
    %   if norm(A(:, j)) < sqrt(eps)
    %     error('Columns of A are linearly dependent.')
    %   end
    if norm(A(:, j)) > sqrt(eps)
        Q(:, j) = A(:, j) / norm(A(:, j));
    else
        Q(:,j) = A(:,j);
    end
end
R = Q'*Asave;


