function indices = kals_assignment(X,D,W,d,lambda4,Eta)

Proj = zeros(length(D),size(X,2));
blocksize1 = 2000;
for k = 1:length(D)
    currentD = D{k}(:,1:d);
    for i = 1:blocksize1:size(X,2)
        blockids = i : min(i+blocksize1-1,size(X,2));
        currentX = X(:,blockids);
        currentW = W(:,blockids);
        [B state] = amb_mfwmd_alternation1(currentX,currentD,currentW);
        R = ( currentX - currentD * B ) .* currentW;
        Proj(k,blockids) = sum(R.^2)+Eta(1,blockids)*lambda4;
    end
end

[ignore indices] = min(Proj);