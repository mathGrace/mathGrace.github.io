function Y = im2patch(im,p,blocksize,stepsize)

% im = double(im);
blocknum = prod(floor((size(im)-blocksize)./stepsize) + 1);
Y = zeros(prod(blocksize),blocknum);

if p == 2
    num = 0;
    nn = ( size(im,1) - blocksize(1) ) / stepsize(1) + 1;
    for j = 1:stepsize(2):size(im,2)-blocksize(2)+1
        
        blocks = im2colstep(im(:,j:j+blocksize(2)-1),blocksize,stepsize);
        Y(:,num+1:num+nn) = blocks;
        num = num + nn;
        
    end
elseif p == 3
    num = 0;
    nn = ( size(im,1) - blocksize(1) ) / stepsize(1) + 1;
    for k = 1:stepsize(3):size(im,3)-blocksize(3)+1
        for j = 1:stepsize(2):size(im,2)-blocksize(2)+1
                  
            blocks = im2colstep(im(:,j:j+blocksize(2)-1,k:k+blocksize(3)-1),blocksize,stepsize);
            Y(:,num+1:num+nn) = blocks;
            num = num + nn;
            
        end
    end
end