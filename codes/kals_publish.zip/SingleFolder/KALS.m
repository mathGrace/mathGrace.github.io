function [imout imout_psnr pixel_remaining D] = KALS(ima_ori,im,trank,trustp,sigma,blocksize,stepsize,OPTIONS)
% KALS is an algorithm of robust hybrid linear modeling. It is designed to
% remove impulsive noise (denoising) and scratches (blind inpainting) from
% images.
% 
% The inputs:
% ima_ori   -   the clean image used for computing the psnr of the output
% im        -   the input noisy image
% trank     -   the dimension of subspaces used for reconstruction
% trustp    -   a lower bound or a guess on the percentage of non-corrupted
%               pixels (or elements)
% sigma     -   the standard deviation of Gaussian noise
% blocksize -   block size for patches, [8 8] is recommended
% stepsize  -   step size to extract patches, [1 1] is recommended
% OPTIONS   -   optional inputs, see comments below for more details
%
%
% The outputs:
% imout     -   output enhanced image
% imout_psnr -  the psnr of the output
% pixel_remaining - a 0-1 matrix of the image size, indicating non-corrupted pixels
% D         -   the final adpative basis of subspaces
%
% Author: Yi Wang  (email: wangx857@umn.edu)
% Reference: Y. Wang, A. Szlam and G. Lerman, Robust Locally Linear Analysis  
%            with Applications to Image Denoising and Blind Inpainting
%% Extract blocks from the image
p = ndims(im);
X = im2patch(im,p,blocksize,stepsize);

%% Set default values for parameters
if nargin < 8
    OPTIONS = struct();
end

if ~isfield(OPTIONS,'IsFix')
    OPTIONS.IsFix = 0; % when 1, fix values in pixel_remaining
end

if ~isfield(OPTIONS,'iternum')
    OPTIONS.iternum = 5; % number of interations
end

if ~isfield(OPTIONS,'outiter')
    OPTIONS.outiter = 1;  % number of the outer loop, up to update W
end

if ~isfield(OPTIONS,'Vim')
    OPTIONS.Vim = rand(size(im));  % regularization 
end

if ~isfield(OPTIONS,'lambda4')
    OPTIONS.lambda4 = 1e-10; % regularization 
end

if ~isfield(OPTIONS,'initer')
    OPTIONS.initer = 2; % number of the inner loop, iterates between 
                        % solving for B and C from |(BC - X) \dot W|_F^2
                        % for initer-1 times
end

if ~isfield(OPTIONS,'method')
    OPTIONS.method = 1; % 1 is denoising; 2 is blind inpainting
end

if ~isfield(OPTIONS,'is_display')
    OPTIONS.is_display = 0; % if 1, display the change in pixel_remaining comparing to the true value
end

if ~isfield(OPTIONS,'true_pixel')
    OPTIONS.true_pixel = []; % the groud truth of non-corrupted pixels
end

if ~isfield(OPTIONS,'pixel_remaining')
    OPTIONS.pixel_remaining = ones(size(im)); % 0-1 matrix, indicating non-corrupted pixels
end

if ~isfield(OPTIONS,'d')
    OPTIONS.d = 8;  % the dimension of subspaces used for clustering
end

if ~isfield(OPTIONS,'medsize')
    OPTIONS.medsize = 4; % size of patches to run a median filter
end


IsFix = OPTIONS.IsFix;
iternum = OPTIONS.iternum;
outiter = OPTIONS.outiter;
lambda4 = OPTIONS.lambda4;
initer = OPTIONS.initer;
Vim = OPTIONS.Vim;
method = OPTIONS.method;
is_display = OPTIONS.is_display;
true_pixel = OPTIONS.true_pixel;
pixel_remaining = OPTIONS.pixel_remaining;
d = OPTIONS.d;
medsize = OPTIONS.medsize;

if is_display
    ddd = setdiff(find(pixel_remaining),find(true_pixel));
    fprintf('initial err=%.4f\n',length(ddd) / numel(pixel_remaining) )
end

%% Initialize dictionary
% disp('initialize D')
a = strcat('PLE_PCA_basis_18dir_',num2str(blocksize(1)),'x',num2str(blocksize(2)),'.mat');
b = strcat('Dct2_',num2str(blocksize(1)),'_sorted');
load(a)
load(b)
blocksize2 = prod(blocksize);
K = 18;
D = cell(1,K+1);
V = cell(1,K+1);
Dk = zeros(blocksize(1)*blocksize(2));
ctrs = zeros(blocksize2,K+1);
T = 3*sigma;

if p == 2
    for k = 1:K
        Dk(:,:) = M_PCA_basis_dir(:,:,k);
        D{k} = Dk;
    end
    D{K+1} = Dct2;
elseif p == 3
    for k = 1:K
        Dk(:,:) = M_PCA_basis_dir(:,:,k);
        D{k} = kron(ones(blocksize(3),1),Dk);
    end
    D{K+1} = kron(ones(blocksize(3),1),Dct2);
end

Y = X;
Eta = rand(1,size(Y,2));
blocksize1 = 2000;
if p == 2
    fn = medfilt2(im,[medsize medsize]);
end

%% Update the structured dictionary

% disp('update D')
for ii = 1:iternum
    
    fprintf('ii=%d\n',ii)
    %% assign data points to subspaces
    W = im2patch(pixel_remaining,p,blocksize,stepsize);
    W = logical(W);
    indices = kals_assignment(X,D,W,d,lambda4,Eta);
    
    for k = 1:K+1
        V{k} = D{k}(:,1:trank);
    end
    
    for j = 1:outiter
        
        %% run ALS within each cluster
        for k = 1:K+1
            idx = (indices==k);
            newX = X(:,idx);
            newW = W(:,idx);
            opts.maxiter = 1;
            opts.initer = initer;
            opts.W = newW;
            opts.A = V{k};
            opts.method = 2; % 2,als; 3,hybrid02; 5,hybrid03;
            newY = ALS_reg2(newX,trustp,trank,opts);
            Y(:,idx) = newY;
        end
        
        imout = patch2im(im,Y,p,blocksize,stepsize);
        imout_psnr = psnr(imout,ima_ori);
        fprintf('psnr=%.2f\n',imout_psnr)
        %% Determine the corrupted pixels, update W
        if ~IsFix
            old = pixel_remaining;
            if method == 1 % denoising
                 r = abs(imout - im) + lambda4*Vim;
            else if method == 2 % blind inpainting, adding information from the median filter
                    if ii == 1
                        r = abs(imout - im) + abs(fn - im) + lambda4*Vim;
                    else
                        r = abs(imout - im) + lambda4*Vim;
                    end
                    
                end
            end
            [sorted_r I] = sort(r(:));
            pixel_remaining = zeros(size(im));
            pixel_remaining(I(1:floor(trustp*numel(im)))) = 1;
            if is_display
                fprintf('dif=%.4f\n',sum(sum(old~=pixel_remaining)) / numel(old) )
                ddd = setdiff(find(pixel_remaining),find(true_pixel));
                fprintf('err=%.4f\n',length(ddd) / numel(pixel_remaining) )
            end
        end
        W = im2patch(pixel_remaining,p,blocksize,stepsize);
        W = logical(W);
    end
    
    %% Update the basis within each cluster by SVD
    for k = 1:K+1
        idx = (indices==k);
        newY= Y(:,idx);
        ctrs(:,k) = mean(newY,2);
        newY0 = newY - repmat(ctrs(:,k),1,sum(idx));
        [u s PCA_basis1] = svd(newY0',0);
        PCA_basis1(:,1) = 1/sqrt(blocksize2);
        PCA_basis1 = grams(PCA_basis1);
        D{k} = PCA_basis1;
    end
    
end

%% Thresholding

for k = 1:K+1
    idx = indices == k;
    currentD = D{k};
    newX = Y(:,idx);
    newY = newX;
    for i = 1:blocksize1:size(newX,2)
        blockids = i : min(i+blocksize1-1,size(newX,2));
        R = currentD' * newX(:,blockids);
        R = R .* ( abs(R)>T );
        newY(:,blockids) = currentD * R;
    end
    Y(:,idx) = newY;
end


%% Reconstruct the image
disp('reconstruct image')
imout = patch2im(im,Y,p,blocksize,stepsize);
imout_psnr = psnr(imout,ima_ori);