function imout = patch2im(im,Y,p,blocksize,stepsize)

if p == 2
    num = 0;
    nn = ( size(im,1) - blocksize(1) ) / stepsize(1) + 1;
    imout = zeros(size(im));

        for j = 1:stepsize(2):size(im,2)-blocksize(2)+1
                  
            cleanvol = col2imstep(Y(:,num+1:num+nn),[size(im,1) blocksize(2)],blocksize,stepsize);
            imout(:,j:j+blocksize(2)-1) = imout(:,j:j+blocksize(2)-1) + cleanvol;
            num = num + nn;
            
        end
    cnt = countcover(size(im),blocksize,stepsize);   
%  %%%   
%     ids = cell(p,1);
%     for jjj = 1:p
%         ids{p} = 1:blocksize(p);
%     end
%     blocknum = prod(floor((size(im)-blocksize)./stepsize) + 1);
%     imout = zeros(size(im));
%     lastids = stepsize .* floor((size(im)-blocksize)./stepsize) + 1;
%     for i = 1 : blocknum
%         
%         imout(ids{:}) = imout(ids{:}) + reshape( Y(:,i), blocksize, blocksize);
%         
%         if (i<blocknum)
%             j = 1;
%             while (ids{j}(1) == lastids(j))
%                 ids{j} = 1:blocksize;
%                 j = j+1;
%             end
%             ids{j} = ids{j}+stepsize(j);
%         end
%         
%     end
%     cnt = countcover(size(im),[blocksize blocksize],[stepsize stepsize]);
    
elseif p == 3
    num = 0;
    nn = ( size(im,1) - blocksize(1) ) / stepsize(1) + 1;
    imout = zeros(size(im));
    for k = 1:stepsize(3):size(im,3)-blocksize(3)+1
        for j = 1:stepsize(2):size(im,2)-blocksize(2)+1
                  
            cleanvol = col2imstep(Y(:,num+1:num+nn),[size(im,1) blocksize(2:3)],blocksize,stepsize);
            imout(:,j:j+blocksize(2)-1,k:k+blocksize(3)-1) = imout(:,j:j+blocksize(2)-1,k:k+blocksize(3)-1) + cleanvol;
            num = num + nn;
            
        end
    end
    cnt = countcover(size(im),blocksize,stepsize);
end

imout = imout ./ cnt;