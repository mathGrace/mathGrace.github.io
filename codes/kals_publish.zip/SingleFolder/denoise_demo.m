%% load image

filename = 'house.png';
ima_ori = imread(filename);
ima_ori = double(ima_ori);

%% set noise level & problem type
sigma = 5;
outPer = 0.05;
ima_size = numel(ima_ori);
method = 1; % 1 is denoising, 2 is blind inpainting

%% add noise
n = sigma * randn(size(ima_ori));
ima_nos = ima_ori + n;
mask_impulsive = zeros(size(ima_nos));
rid = randperm(ima_size);
ima_nos(rid(1:floor(outPer*ima_size))) = round(255*rand(1,floor(outPer*ima_size)));
mask_impulsive(rid(1:floor(outPer*ima_size))) = 1;
if method == 2
   load('./images/mask256_1a') 
   ima_nos(mask==1) = 40;
end

%% denoising

opts.method = method;
[imout imout_psnr pixel_remaining D] = KALS(ima_ori,ima_nos,20,1-outPer*1.2,sigma,[8 8],[8 8],opts);
% [imout imout_psnr pixel_remaining D] = KALS(ima_ori,im,trank,trustp,sigma,blocksize,stepsize,OPTIONS)